'use client';

import { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function NewsletterPage() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email) {
      setIsSubscribed(true);
      setName('');
      setEmail('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900/20 to-slate-900">
      <Header />
      
      <div className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Join for Fiction & Story Updates
            </h1>
            <p className="text-xl text-purple-200 max-w-3xl mx-auto">
              Stay connected with the latest stories, writing insights, and exclusive content. 
              Subscribe and instantly receive 4 free microfictions as our welcome gift.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-3xl p-8 md:p-10 border border-purple-500/20 shadow-2xl">
                {!isSubscribed ? (
                  <>
                    <div className="text-center mb-8">
                      <div className="w-16 h-16 flex items-center justify-center bg-purple-600/20 rounded-full mx-auto mb-4">
                        <i className="ri-mail-line text-purple-300 text-2xl"></i>
                      </div>
                      <h2 className="text-2xl font-bold text-white mb-2">
                        Subscribe to Our Newsletter
                      </h2>
                      <p className="text-purple-200">
                        Get exclusive access to new stories and writing insights
                      </p>
                    </div>
                    
                    <form id="newsletter-form" onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-purple-200 mb-2">
                          Your Name
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          required
                          className="w-full px-4 py-3 bg-slate-700/50 border border-purple-500/20 rounded-xl text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all text-sm"
                          placeholder="Enter your full name"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-purple-200 mb-2">
                          Email Address
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                          className="w-full px-4 py-3 bg-slate-700/50 border border-purple-500/20 rounded-xl text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all text-sm"
                          placeholder="Enter your email address"
                        />
                      </div>
                      
                      <button
                        type="submit"
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white px-6 py-4 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap"
                      >
                        Subscribe & Get Free Stories
                      </button>
                    </form>
                    
                    <p className="text-center text-sm text-purple-300 mt-6">
                      Subscribe and instantly receive 4 free microfictions.
                    </p>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 flex items-center justify-center bg-green-600/20 rounded-full mx-auto mb-4">
                      <i className="ri-check-line text-green-400 text-2xl"></i>
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-4">
                      Welcome to the Community!
                    </h2>
                    <p className="text-purple-200 mb-6">
                      Thank you for subscribing! Check your email for your free microfictions and future updates.
                    </p>
                    <button
                      onClick={() => setIsSubscribed(false)}
                      className="text-purple-300 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
                    >
                      Subscribe another email
                    </button>
                  </div>
                )}
              </div>
            </div>
            
            <div className="order-1 lg:order-2">
              <div className="space-y-8">
                <div className="text-center lg:text-left">
                  <h3 className="text-3xl font-bold text-white mb-6">
                    What You'll Receive
                  </h3>
                </div>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full flex-shrink-0">
                      <i className="ri-book-line text-purple-300 text-xl"></i>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">
                        Free Microfictions
                      </h4>
                      <p className="text-purple-200">
                        Instant access to all four acclaimed microfictions: "The Shadow in the Mirror", "Smile", "Daria", and "The Night Love Found Him"
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full flex-shrink-0">
                      <i className="ri-notification-line text-purple-300 text-xl"></i>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">
                        New Release Updates
                      </h4>
                      <p className="text-purple-200">
                        Be the first to know about new books, stories, and exclusive content releases
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full flex-shrink-0">
                      <i className="ri-quill-pen-line text-purple-300 text-xl"></i>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">
                        Writing Insights
                      </h4>
                      <p className="text-purple-200">
                        Behind-the-scenes content, writing tips, and creative process insights from Amit Sharma
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full flex-shrink-0">
                      <i className="ri-vip-crown-line text-purple-300 text-xl"></i>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">
                        Exclusive Content
                      </h4>
                      <p className="text-purple-200">
                        Subscriber-only stories, early previews, and special discounts on upcoming releases
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
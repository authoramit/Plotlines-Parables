'use client';

export default function AuthorBio() {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-4xl font-bold text-white mb-6">Meet Amit Sharma</h2>
            <div className="space-y-6 text-purple-200 text-lg leading-relaxed">
              <p>
                Amit Sharma is an Indian author whose literary journey spans the vast landscape of human emotion and divine mystery. 
                With roots deeply embedded in Indian mythology and a keen eye for contemporary psychological nuances, 
                he creates stories that resonate across cultural and temporal boundaries.
              </p>
              <p>
                His writing encompasses multiple genres—from epic mythology and tender romance to spine-chilling horror 
                and thought-provoking philosophical micro-fiction. Each story is crafted with precision, 
                exploring the intricate tapestry of human nature while maintaining accessibility and emotional depth.
              </p>
              <p>
                Amit's approach to storytelling is rooted in the belief that every narrative, regardless of its length or genre, 
                should touch the reader's soul and provoke introspection. His work reflects a deep understanding of both 
                ancient wisdom and modern sensibilities, creating a unique voice in contemporary Indian literature.
              </p>
              <p>
                When not writing, Amit can be found exploring ancient temples, studying comparative mythology, 
                or simply observing the everyday miracles that inspire his next story.
              </p>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/de8e4cc54b260ed0978677e771f92824.webp"
                  alt="Amit Sharma - Author"
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-purple-600/20 rounded-full backdrop-blur-sm border border-purple-500/30 flex items-center justify-center">
                <div className="w-12 h-12 flex items-center justify-center">
                  <i className="ri-quill-pen-line text-purple-300 text-2xl"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
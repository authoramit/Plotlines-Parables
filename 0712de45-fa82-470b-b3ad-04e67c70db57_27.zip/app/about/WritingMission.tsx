'use client';

export default function WritingMission() {
  return (
    <section className="py-20 px-4 bg-slate-800/30 backdrop-blur-sm">
      <div className="container mx-auto max-w-4xl text-center">
        <h2 className="text-4xl font-bold text-white mb-8">Writing Mission</h2>
        
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-purple-500/20 shadow-2xl">
          <div className="w-16 h-16 flex items-center justify-center bg-purple-600/20 rounded-full mx-auto mb-8">
            <i className="ri-heart-3-line text-purple-300 text-2xl"></i>
          </div>
          
          <blockquote className="text-xl md:text-2xl text-purple-100 leading-relaxed mb-8 italic">
            "To create multi-genre storytelling rooted in emotional truth and spiritual imagination, 
            bridging the gap between ancient wisdom and contemporary understanding."
          </blockquote>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full mx-auto mb-4">
                <i className="ri-emotion-line text-purple-300 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Emotional Truth</h3>
              <p className="text-purple-200 text-sm">
                Every story explores the authentic depths of human emotion and experience
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full mx-auto mb-4">
                <i className="ri-ancient-gate-line text-purple-300 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Spiritual Imagination</h3>
              <p className="text-purple-200 text-sm">
                Weaving divine symbolism and mythological wisdom into contemporary narratives
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full mx-auto mb-4">
                <i className="ri-global-line text-purple-300 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Universal Connection</h3>
              <p className="text-purple-200 text-sm">
                Creating stories that resonate across cultures and generations
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
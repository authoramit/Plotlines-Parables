
'use client';

import Header from '../../components/Header';
import Footer from '../../components/Footer';
import AboutHero from './AboutHero';
import AuthorBio from './AuthorBio';
import WritingMission from './WritingMission';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900/20 to-slate-900">
      <Header />
      <AboutHero />
      <AuthorBio />
      <WritingMission />
      <Footer />
    </div>
  );
}

'use client';

export default function Timeline() {
  const milestones = [
    {
      year: '2020',
      title: 'Literary Journey Begins',
      description: 'Started writing philosophical micro-fiction, exploring themes of human nature and divine connection.'
    },
    {
      year: '2021',
      title: 'First Microfiction Collection',
      description: 'Released four acclaimed microfictions: "The Shadow in the Mirror", "Smile", "Daria", and "The Night Love Found Him".'
    },
    {
      year: '2022',
      title: 'Genre Expansion',
      description: 'Began exploring mythology and psychological horror, developing a unique voice that bridges ancient and modern storytelling.'
    },
    {
      year: '2023',
      title: 'Major Work Development',
      description: 'Started working on the epic mythological novel "KALKI: The Call of Destiny".'
    },
    {
      year: '2024',
      title: 'KALKI Publication',
      description: 'Released "KALKI: The Call of Destiny" - a groundbreaking mythological novel exploring divine destiny and human transformation.'
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-4xl font-bold text-white text-center mb-16">Literary Journey</h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 md:left-1/2 md:transform md:-translate-x-px top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 to-purple-300"></div>
          
          <div className="space-y-12">
            {milestones.map((milestone, index) => (
              <div 
                key={index} 
                className={`relative flex items-center ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                } flex-col md:flex-row`}
              >
                {/* Timeline dot */}
                <div className="absolute left-8 md:left-1/2 md:transform md:-translate-x-1/2 w-4 h-4 bg-purple-500 rounded-full border-4 border-slate-900 z-10"></div>
                
                {/* Content */}
                <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'md:text-right md:pr-12' : 'md:text-left md:pl-12'} ml-16 md:ml-0`}>
                  <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20 shadow-lg">
                    <div className="text-2xl font-bold text-purple-300 mb-2">
                      {milestone.year}
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-3">
                      {milestone.title}
                    </h3>
                    <p className="text-purple-200 leading-relaxed">
                      {milestone.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
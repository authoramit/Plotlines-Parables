'use client';

export default function AboutHero() {
  return (
    <section 
      className="relative py-32 px-4"
      style={{
        backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.8), rgba(88, 28, 135, 0.4)), url('https://readdy.ai/api/search-image?query=Cosmic%20nebula%20background%20with%20writing%20desk%20and%20books%20floating%20in%20space%2C%20author%20workspace%20in%20cosmic%20setting%2C%20purple%20and%20blue%20space%20colors%2C%20ethereal%20literary%20atmosphere%2C%20minimalist%20composition%20with%20starlight%2C%20dreamy%20space%20environment%20for%20writer&width=1920&height=1080&seq=about-hero-1&orientation=landscape')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="container mx-auto max-w-4xl text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
          About the Author
        </h1>
        <p className="text-xl md:text-2xl text-purple-200 max-w-3xl mx-auto leading-relaxed">
          Amit Sharma crafts stories that bridge the ancient and the contemporary, 
          weaving mythology with modern psychology to explore the deepest corners of human experience.
        </p>
      </div>
    </section>
  );
}
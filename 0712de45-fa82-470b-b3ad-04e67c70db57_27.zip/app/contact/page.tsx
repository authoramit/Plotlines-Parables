'use client';

import { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setIsSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900/20 to-slate-900">
      <Header />
      
      <div className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Get in Touch
            </h1>
            <p className="text-xl text-purple-200 max-w-3xl mx-auto">
              For speaking requests, interviews, collaborations, or any questions about the stories, 
              feel free to reach out. I'd love to hear from you.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="order-2 lg:order-1">
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-3xl p-8 md:p-10 border border-purple-500/20 shadow-2xl">
                {!isSubmitted ? (
                  <>
                    <div className="mb-8">
                      <h2 className="text-3xl font-bold text-white mb-4">
                        Send a Message
                      </h2>
                      <p className="text-purple-200">
                        I'll get back to you as soon as possible.
                      </p>
                    </div>
                    
                    <form id="contact-form" onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-purple-200 mb-2">
                          Your Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 bg-slate-700/50 border border-purple-500/20 rounded-xl text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all text-sm"
                          placeholder="Enter your full name"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-purple-200 mb-2">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 bg-slate-700/50 border border-purple-500/20 rounded-xl text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all text-sm"
                          placeholder="Enter your email address"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-purple-200 mb-2">
                          Message *
                        </label>
                        <textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleChange}
                          required
                          maxLength={500}
                          rows={6}
                          className="w-full px-4 py-3 bg-slate-700/50 border border-purple-500/20 rounded-xl text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all resize-none text-sm"
                          placeholder="Tell me about your inquiry, collaboration idea, or any questions you have..."
                        />
                        <div className="text-right text-xs text-purple-300 mt-1">
                          {formData.message.length}/500 characters
                        </div>
                      </div>
                      
                      <button
                        type="submit"
                        disabled={formData.message.length > 500}
                        className="w-full bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-6 py-4 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap"
                      >
                        Send Message
                      </button>
                    </form>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 flex items-center justify-center bg-green-600/20 rounded-full mx-auto mb-4">
                      <i className="ri-check-line text-green-400 text-2xl"></i>
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-4">
                      Message Sent Successfully!
                    </h2>
                    <p className="text-purple-200 mb-6">
                      Thank you for reaching out. I'll get back to you within 24-48 hours.
                    </p>
                    <button
                      onClick={() => setIsSubmitted(false)}
                      className="text-purple-300 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
                    >
                      Send another message
                    </button>
                  </div>
                )}
              </div>
            </div>
            
            {/* Contact Information */}
            <div className="order-1 lg:order-2">
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold text-white mb-6">
                    Let's Connect
                  </h2>
                  <p className="text-lg text-purple-200 leading-relaxed mb-8">
                    Whether you're interested in collaborations, speaking engagements, 
                    interviews, or simply want to discuss stories and writing, 
                    I'm always excited to connect with fellow literature enthusiasts.
                  </p>
                </div>
                
                <div className="space-y-6">
                  <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20">
                    <h3 className="text-xl font-semibold text-white mb-4">
                      What I'm Available For
                    </h3>
                    <ul className="space-y-3 text-purple-200">
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                        Speaking requests and literary events
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                        Media interviews and podcast appearances
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                        Writing collaborations and projects
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                        Book clubs and reading discussions
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                        General questions about my work
                      </li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20">
                    <h3 className="text-xl font-semibold text-white mb-4">
                      Follow on Social Media
                    </h3>
                    <div className="flex space-x-4">
                      <a 
                        href="#" 
                        className="flex items-center justify-center w-12 h-12 bg-purple-600/20 hover:bg-purple-600 rounded-full transition-all duration-300 transform hover:scale-110 cursor-pointer"
                      >
                        <i className="ri-instagram-line text-purple-300 hover:text-white text-xl"></i>
                      </a>
                      <a 
                        href="#" 
                        className="flex items-center justify-center w-12 h-12 bg-purple-600/20 hover:bg-purple-600 rounded-full transition-all duration-300 transform hover:scale-110 cursor-pointer"
                      >
                        <i className="ri-twitter-x-line text-purple-300 hover:text-white text-xl"></i>
                      </a>
                    </div>
                    <p className="text-sm text-purple-300 mt-4">
                      Follow for writing updates, behind-the-scenes content, and literary discussions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
'use client';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  image: string;
}

interface BlogCardProps {
  post: BlogPost;
}

export default function BlogCard({ post }: BlogCardProps) {
  return (
    <article className="group">
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-purple-500/20">
        <div className="aspect-[3/2] relative overflow-hidden">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent"></div>
          <div className="absolute top-4 left-4">
            <span className="inline-block bg-purple-600/90 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-medium">
              {post.category}
            </span>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex items-center text-sm text-purple-300 mb-3">
            <span>{post.date}</span>
            <span className="mx-2">•</span>
            <span>{post.readTime}</span>
          </div>
          
          <h2 className="text-xl font-bold text-white mb-3 line-clamp-2 group-hover:text-purple-200 transition-colors">
            {post.title}
          </h2>
          
          <p className="text-purple-200 text-sm leading-relaxed mb-6 line-clamp-3">
            {post.excerpt}
          </p>
          
          <button className="flex items-center text-purple-300 hover:text-white font-medium transition-colors group-hover:translate-x-1 transform duration-300 cursor-pointer whitespace-nowrap">
            Read More
            <div className="w-4 h-4 flex items-center justify-center ml-2">
              <i className="ri-arrow-right-line text-sm"></i>
            </div>
          </button>
        </div>
      </div>
    </article>
  );
}

'use client';

import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900/20 to-slate-900">
      <Header />
      
      <div className="flex-1 flex items-center justify-center px-4 py-20">
        <div className="text-center">
          <h1 className="text-6xl md:text-7xl font-bold text-white mb-6">
            Coming Soon
          </h1>
          <p className="text-xl text-purple-200 max-w-2xl mx-auto">
            Exciting blog content is on the way. Stay tuned for insights on storytelling, mythology, and the creative process.
          </p>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}

'use client';

import Link from 'next/link';
import Header from '../components/Header';
import Hero from '../components/Hero';
import BookGrid from '../components/BookGrid';
import Footer from '../components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900/20 to-slate-900">
      <Header />
      <Hero />
      <BookGrid />
      <Footer />
    </div>
  );
}
'use client';

import Header from '../../components/Header';
import Footer from '../../components/Footer';
import MainNovel from './MainNovel';
import FreeMicrofictions from './FreeMicrofictions';

export default function BooksPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900/20 to-slate-900">
      <Header />
      
      <div className="py-20 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Books & Stories
            </h1>
            <p className="text-xl text-purple-200 max-w-3xl mx-auto">
              Explore a collection of stories spanning mythology, romance, horror, and philosophical fiction
            </p>
          </div>
          
          <MainNovel />
          <FreeMicrofictions />
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
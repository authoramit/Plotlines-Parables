'use client';

export default function FreeMicrofictions() {
  const microfictions = [
    {
      title: "The Shadow in the Mirror",
      description: "Reflections reveal more than you expect in this psychological thriller.",
      genre: "Thriller",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/30baa26d0e7d464e1f54bc7bc53ebce5.png"
    },
    {
      title: "The Night Love Found Him",
      description: "Love arrives when least expected in this tender romantic tale.",
      genre: "Philosophical",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/61d22063e218d528eba84a9dcb935211.png"
    },
    {
      title: "Smile",
      description: "Sometimes a smile hides the deepest secrets and darkest truths.",
      genre: "Romantic/Quirky",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/d98f239dc46324816c5f4a7f289a6590.png"
    },
    {
      title: "Daria",
      description: "A name that carries untold stories and forgotten memories.",
      genre: "Horror",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/f87803c6f580d1af81837842ed0f6aab.png"
    }
  ];

  return (
    <section>
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-white mb-4">Free Microfictions</h2>
        <div className="w-24 h-1 bg-purple-500 mx-auto mb-4"></div>
        <p className="text-lg text-purple-200 max-w-2xl mx-auto">
          Bite-sized stories that pack powerful emotional punches. Each microfiction explores deep themes in just a few hundred words.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {microfictions.map((story, index) => (
          <div key={index} className="group">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-purple-500/20">
              <div className="aspect-[2/3] relative overflow-hidden">
                <img
                  src={story.image}
                  alt={story.title}
                  className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <div className="p-6">
                <div className="mb-3">
                  <span className="inline-block bg-purple-600/20 text-purple-200 px-3 py-1 rounded-full text-xs font-medium">
                    {story.genre}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-3">
                  {story.title}
                </h3>

                <p className="text-sm text-purple-200 mb-6 leading-relaxed">
                  {story.description}
                </p>

                <button className="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap">
                  Read Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center mt-12">
        <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/20">
          <div className="w-12 h-12 flex items-center justify-center bg-purple-600/20 rounded-full mx-auto mb-4">
            <i className="ri-gift-line text-purple-300 text-xl"></i>
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">
            Subscribe for Free & Join the Community
          </h3>
          <p className="text-purple-200 mb-6 max-w-2xl mx-auto">
            Subscribe to our newsletter and instantly receive all four microfictions as a welcome gift. 
            Plus, get updates on new releases and exclusive content.
          </p>
          <button className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap">
            Subscribe
          </button>
        </div>
      </div>
    </section>
  );
}
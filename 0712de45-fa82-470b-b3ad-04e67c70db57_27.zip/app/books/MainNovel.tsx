
'use client';

import Link from 'next/link';

export default function MainNovel() {
  return (
    <section className="mb-20">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-white mb-4">Paperback</h2>
        <div className="w-24 h-1 bg-purple-500 mx-auto"></div>
      </div>
      
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-purple-500/20 shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="mb-6">
              <span className="inline-block bg-purple-600/20 text-purple-200 px-4 py-2 rounded-full text-sm font-medium mb-4">
                Epic Mythology
              </span>
              <h3 className="text-4xl font-bold text-white mb-2">
                KALKI: The Call of Destiny
              </h3>
              <p className="text-xl text-purple-300 font-semibold mb-6">
                Born Human. Destined Divine.
              </p>
            </div>
            
            <div className="prose prose-lg text-purple-200 mb-8">
              <p className="mb-4">
                In an age where darkness threatens to consume the world, a young man discovers his divine heritage and the weight of cosmic responsibility. KALKI weaves ancient mythology with contemporary storytelling, exploring themes of destiny, transformation, and the eternal battle between light and shadow.
              </p>
              <p className="mb-4">
                This epic novel reimagines the final avatar of Vishnu through a modern lens, questioning what it truly means to be chosen by fate while maintaining one's humanity. A tale of spiritual awakening, cosmic battles, and the price of divine purpose.
              </p>
              <p>
                Perfect for readers of mythology, fantasy, and philosophical fiction who seek stories that challenge both mind and spirit.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="text-3xl font-bold text-purple-300 mb-2 sm:mb-0">
                ₹599
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link 
                  href="https://store.pothi.com/book/amit-sharma-k-l-k-i"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap"
                >
                  Buy Now
                </Link>
                <button className="border-2 border-purple-400 text-purple-200 hover:bg-purple-400 hover:text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap">
                  Read Preview
                </button>
              </div>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <img
                  src="https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/0a7c6982620c9db386d459632e9fb02f.jfif"
                  alt="KALKI: The Call of Destiny"
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-purple-600/20 rounded-full backdrop-blur-sm border border-purple-500/30 flex items-center justify-center">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-vip-crown-line text-purple-300 text-xl"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

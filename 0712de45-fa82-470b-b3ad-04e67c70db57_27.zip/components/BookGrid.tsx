'use client';

import Link from 'next/link';

export default function BookGrid() {
  const books = [
    {
      id: 1,
      title: "KALKI: The Call of Destiny",
      type: "Novel",
      price: "₹599",
      tagline: "Born Human. Destined Divine.",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/0a7c6982620c9db386d459632e9fb02f.jfif"
    },
    {
      id: 2,
      title: "The Shadow in the Mirror",
      type: "Microfiction",
      price: "Free",
      tagline: "Reflections reveal more than you expect.",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/30baa26d0e7d464e1f54bc7bc53ebce5.png"
    },
    {
      id: 3,
      title: "The Night Love Found Him",
      type: "Microfiction",
      price: "Free",
      tagline: "Love arrives when least expected.",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/61d22063e218d528eba84a9dcb935211.png"
    },
    {
      id: 4,
      title: "Smile",
      type: "Microfiction",
      price: "Free",
      tagline: "Sometimes a smile hides the deepest secrets.",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/d98f239dc46324816c5f4a7f289a6590.png"
    },
    {
      id: 5,
      title: "Daria",
      type: "Microfiction",
      price: "Free",
      tagline: "A name that carries untold stories.",
      image: "https://static.readdy.ai/image/b4dbc9e0fdc3a2d40f295b626ebb55fb/f87803c6f580d1af81837842ed0f6aab.png"
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Featured Works
          </h2>
          <p className="text-xl text-purple-200 max-w-2xl mx-auto">
            Explore stories that span mythology, psychology, romance, and the depths of human emotion
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
          {books.map((book) => (
            <div key={book.id} className="group">
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-purple-500/20">
                <div className="aspect-[2/3] relative overflow-hidden">
                  <img
                    src={book.image}
                    alt={book.title}
                    className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                
                <div className="p-6">
                  <div className="mb-2">
                    <span className="inline-block bg-purple-600/20 text-purple-200 px-3 py-1 rounded-full text-xs font-medium">
                      {book.type}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-bold text-white mb-2 line-clamp-2">
                    {book.title}
                  </h3>
                  
                  <p className="text-sm text-purple-200 mb-4 line-clamp-2">
                    {book.tagline}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-purple-300">
                      {book.price}
                    </span>
                    
                    <Link 
                      href="/books"
                      className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap"
                    >
                      {book.price === 'Free' ? 'Read Now' : 'Buy Now'}
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link 
            href="/books"
            className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap"
          >
            View All Books
          </Link>
        </div>
      </div>
    </section>
  );
}
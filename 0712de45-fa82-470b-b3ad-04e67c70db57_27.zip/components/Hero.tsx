'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center text-center"
      style={{
        backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.7), rgba(88, 28, 135, 0.3)), url('https://readdy.ai/api/search-image?query=Deep%20space%20nebula%20with%20purple%20and%20blue%20cosmic%20clouds%2C%20stars%20scattered%20across%20dark%20space%2C%20ethereal%20galaxy%20background%20with%20subtle%20glowing%20dust%20particles%2C%20minimal%20and%20clean%20astronomical%20photography%20style%2C%20dark%20navy%20and%20purple%20tones%2C%20professional%20space%20photography&width=1920&height=1080&seq=hero-nebula-1&orientation=landscape')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
            <span className="font-pacifico">Plotlines & Parables</span>
          </h1>
          <h2 className="text-2xl md:text-3xl text-purple-200 mb-4">
            By Amit Sharma
          </h2>
          <p className="text-lg md:text-xl text-purple-100 mb-12 max-w-2xl mx-auto leading-relaxed">
            "Stories that journey through emotion, myth, and mind."
          </p>
          
          <div className="space-y-4 sm:space-y-0 sm:space-x-6 sm:flex sm:justify-center">
            <Link 
              href="/books"
              className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap"
            >
              Explore Stories
            </Link>
            <Link 
              href="/about"
              className="inline-block border-2 border-purple-400 text-purple-200 hover:bg-purple-400 hover:text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              About the Author
            </Link>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-6 flex items-center justify-center">
          <i className="ri-arrow-down-line text-purple-200 text-2xl"></i>
        </div>
      </div>
    </section>
  );
}
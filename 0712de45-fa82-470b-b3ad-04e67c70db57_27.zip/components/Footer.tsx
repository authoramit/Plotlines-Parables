
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-slate-900/80 backdrop-blur-sm border-t border-purple-500/20 py-12">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="text-2xl font-bold text-white mb-4 block">
              <span className="font-pacifico">Plotlines & Parables</span>
            </Link>
            <p className="text-purple-200 mb-4 max-w-md">
              Stories that journey through emotion, myth, and mind. Exploring the depths of human nature through mythology, romance, horror, and philosophical fiction.
            </p>
            <div className="flex space-x-4">
              <a href="https://www.instagram.com/author__amit?igsh=MXE2anY0czl1aGZtcA==" className="w-10 h-10 flex items-center justify-center bg-purple-600 hover:bg-purple-700 rounded-full transition-colors cursor-pointer">
                <i className="ri-instagram-line text-white text-lg"></i>
              </a>
              <a href="https://x.com/author__amit?t=_2Tv7Xtu-po3WYHtSRiQnQ&s=09" className="w-10 h-10 flex items-center justify-center bg-purple-600 hover:bg-purple-700 rounded-full transition-colors cursor-pointer">
                <i className="ri-twitter-x-line text-white text-lg"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                  About
                </Link>
              </li>
              <li>
                <Link href="/books" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                  Books
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/newsletter" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                  Newsletter
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Connect</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/contact" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/newsletter" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                  Subscribe
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-purple-500/20 mt-8 pt-8 text-center">
          <p className="text-purple-200">
            2025 Plotlines & Parables by Amit Sharma. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

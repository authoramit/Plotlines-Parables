'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="relative z-50">
      <nav className="bg-slate-900/80 backdrop-blur-sm border-b border-purple-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="text-2xl font-bold text-white">
              <span className="font-pacifico">Plotlines & Parables</span>
            </Link>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/about" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                About
              </Link>
              <Link href="/books" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                Books
              </Link>
              <Link href="/blog" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                Blog
              </Link>
              <Link href="/newsletter" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                Newsletter
              </Link>
              <Link href="/contact" className="text-purple-200 hover:text-white transition-colors cursor-pointer">
                Contact
              </Link>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden w-6 h-6 flex items-center justify-center cursor-pointer"
            >
              <i className="ri-menu-line text-white text-xl"></i>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-slate-900/95 backdrop-blur-sm border-t border-purple-500/20">
            <div className="px-4 py-3 space-y-3">
              <Link href="/" className="block text-purple-200 hover:text-white transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/about" className="block text-purple-200 hover:text-white transition-colors cursor-pointer">
                About
              </Link>
              <Link href="/books" className="block text-purple-200 hover:text-white transition-colors cursor-pointer">
                Books
              </Link>
              <Link href="/blog" className="block text-purple-200 hover:text-white transition-colors cursor-pointer">
                Blog
              </Link>
              <Link href="/newsletter" className="block text-purple-200 hover:text-white transition-colors cursor-pointer">
                Newsletter
              </Link>
              <Link href="/contact" className="block text-purple-200 hover:text-white transition-colors cursor-pointer">
                Contact
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}